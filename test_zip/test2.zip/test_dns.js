/**
 * @copyright 2017-2020 Information & Communications Research Laboratories,
 *                      Industrial Technology Research Institute
 * @file MEC DNS RESTful API handler unit test
 */
const assert = require('chai').assert;
const proxyquire = require('proxyquire');
const sinon = require('sinon');

const TEST_SERVER_IP = '127.0.0.1';
const TEST_SERVER_PORT = 5258;
const TEST_SERVER_ROOT = '/dns/records';

describe('MEC DNS RESTful Service', function() {
  context('MEC DNS RESTful server life cycle management', function() {
    it('should start the restful server and stop correctly', function(done) {
      var http = require('http');
      var app = require('../app');
      var server = http.createServer(app);
      server.listen(TEST_SERVER_PORT);
      server.close();
      done();
    });
  });
});

describe('/dns/records/', function() {
  const TEST_DOMAIN_TYPE = 'A';
  const TEST_DOMAIN_NAME = 'test.mec.com';
  const TEST_DNS_RECORD_ID = TEST_DOMAIN_NAME + '/' + TEST_DOMAIN_TYPE;
  const TEST_IP = '1.1.1.1';

  const http = require('http');
  const express = require('express');

  var sandbox;
  var app;
  var server;

  beforeEach(function() {
    sandbox = sinon.sandbox.create();
    app = express();
    server = http.createServer(app);
    server.listen(TEST_SERVER_PORT);
  });
  afterEach(function() {
    server.close();
    sandbox.restore();
  });

  context('when adding a new dns record via POST /dns/records', function() {
    it('should save the dns record to redis and return 201', function(done) {
      let MockDNSRecord = require('../model/dns_record');
      sandbox.stub(MockDNSRecord.prototype, 'addRecord')
        .callsArgWithAsync(3, null, TEST_DNS_RECORD_ID);

      var dnsRouter = proxyquire('../routes/dns', {
        'DNSRecord': MockDNSRecord,
      });

      app.use(TEST_SERVER_ROOT, dnsRouter);

      /* create a http request and send */
      var content = JSON.stringify({
        'type': TEST_DOMAIN_TYPE,
        'domain': TEST_DOMAIN_NAME,
        'ip': TEST_IP,
      });
      var options = {
        hostname: TEST_SERVER_IP,
        port: TEST_SERVER_PORT,
        path: TEST_SERVER_ROOT,
        method: 'POST',
        headers: {
          'Content-type': 'application/json',
          'Content-length': content.length,
        },
      };
      var req = http.request(options, function(res) {
        assert.strictEqual(res.statusCode, 201);
        done();
      });
      req.on('error', function() {
        assert.fail();
      });
      req.write(content);
      req.end();
    });
  });

  context('when adding a new dns record with a null type via POST /dns/records', function() {
    it('should return error code 400', function(done) {
      let MockDNSRecord = require('../model/dns_record');
      sandbox.stub(MockDNSRecord.prototype, 'addRecord')
        .callsArgWithAsync(3, null, TEST_DNS_RECORD_ID);

      var dnsRouter = proxyquire('../routes/dns', {
        'DNSRecord': MockDNSRecord,
      });

      app.use(TEST_SERVER_ROOT, dnsRouter);

      /* create a http request and send */
      var content = JSON.stringify({
        'type': null,
        'domain': TEST_DOMAIN_NAME,
        'ip': TEST_IP,
      });
      var options = {
        hostname: TEST_SERVER_IP,
        port: TEST_SERVER_PORT,
        path: TEST_SERVER_ROOT,
        method: 'POST',
        headers: {
          'Content-type': 'application/json',
          'Content-length': content.length,
        },
      };
      var req = http.request(options, function(res) {
        assert.strictEqual(res.statusCode, 400);
        done();
      });
      req.on('error', function() {
        assert.fail();
      });
      req.write(content);
      req.end();
    });
  });

  context('when deleting a dns record via DELETE /dns/records', function() {
    it('should delete the dns record and return 204', function(done) {
      let MockDNSRecord = require('../model/dns_record');
      sandbox.stub(MockDNSRecord.prototype, 'delRecord')
        .callsArgWithAsync(2, null);

      var dnsRouter = proxyquire('../routes/dns', {
        'DNSRecord': MockDNSRecord,
      });

      app.use(TEST_SERVER_ROOT, dnsRouter);

      /* create a http request and send */
      var options = {
        hostname: TEST_SERVER_IP,
        port: TEST_SERVER_PORT,
        path: TEST_SERVER_ROOT + '/' + TEST_DOMAIN_NAME + '/' + TEST_DOMAIN_TYPE,
        method: 'DELETE',
      };
      var req = http.request(options, function(res) {
        assert.strictEqual(res.statusCode, 204);
        done();
      });
      req.on('error', function() {
        assert.fail();
      });
      req.end();
    });
  });

  context('when updating a dns record via PUT /dns/records', function() {
    it('should update the dns record and return 200', function(done) {
      let MockDNSRecord = require('../model/dns_record');
      sandbox.stub(MockDNSRecord.prototype, 'updateRecord')
        .callsArgWithAsync(3, null, TEST_DNS_RECORD_ID);

      var dnsRouter = proxyquire('../routes/dns', {
        'DNSRecord': MockDNSRecord,
      });

      app.use(TEST_SERVER_ROOT, dnsRouter);

      /* create a http request and send */
      var content = JSON.stringify({
        'ip': TEST_IP,
      });
      var options = {
        hostname: TEST_SERVER_IP,
        port: TEST_SERVER_PORT,
        path: TEST_SERVER_ROOT + '/' + TEST_DOMAIN_NAME + '/' + TEST_DOMAIN_TYPE,
        method: 'PUT',
        headers: {
          'Content-type': 'application/json',
          'Content-length': content.length,
        },
      };
      var req = http.request(options, function(res) {
        assert.strictEqual(res.statusCode, 200);
        done();
      });
      req.on('error', function() {
        assert.fail();
      });
      req.write(content);
      req.end();
    });
  });
  context('when updating a dns record without ip address in body via PUT /dns/records', function() {
    it('should return error code 400', function(done) {
      let MockDNSRecord = require('../model/dns_record');
      sandbox.stub(MockDNSRecord.prototype, 'updateRecord')
        .callsArgWithAsync(3, null, TEST_DNS_RECORD_ID);

      var dnsRouter = proxyquire('../routes/dns', {
        'DNSRecord': MockDNSRecord,
      });

      app.use(TEST_SERVER_ROOT, dnsRouter);

      /* create a http request and send */
      var content = JSON.stringify({
        'ip': '',
      });
      var options = {
        hostname: TEST_SERVER_IP,
        port: TEST_SERVER_PORT,
        path: TEST_SERVER_ROOT + '/' + TEST_DOMAIN_NAME + '/' + TEST_DOMAIN_TYPE,
        method: 'PUT',
        headers: {
          'Content-type': 'application/json',
          'Content-length': content.length,
        },
      };
      var req = http.request(options, function(res) {
        assert.strictEqual(res.statusCode, 400);
        done();
      });
      req.on('error', function() {
        assert.fail();
      });
      req.write(content);
      req.end();
    });
  });

  context('when retrieving a dns record via GET /dns/records', function() {
    it('should return the dns record and return 200', function(done) {
      let MockDNSRecord = require('../model/dns_record');
      sandbox.stub(MockDNSRecord.prototype, 'getRecord')
        .callsArgWithAsync(2, null, TEST_IP);

      var dnsRouter = proxyquire('../routes/dns', {
        'DNSRecord': MockDNSRecord,
      });

      app.use(TEST_SERVER_ROOT, dnsRouter);

      /* create a http request and send */
      var options = {
        hostname: TEST_SERVER_IP,
        port: TEST_SERVER_PORT,
        path: TEST_SERVER_ROOT + '/' + TEST_DOMAIN_NAME + '/' + TEST_DOMAIN_TYPE,
        method: 'GET',
      };
      var req = http.request(options, function(res) {
        assert.strictEqual(res.statusCode, 200);

        var content = '';
        res.on('data', function(chunk) {
          content += chunk;
        });
        res.on('end', function() {
          var result = JSON.parse(content);
          assert.strictEqual(result.ip, TEST_IP);
          done();
        });
      });
      req.on('error', function() {
        assert.fail();
      });
      req.end();
    });
  });
});


